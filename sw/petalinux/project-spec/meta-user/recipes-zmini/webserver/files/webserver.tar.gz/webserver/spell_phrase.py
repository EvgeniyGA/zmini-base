import os
import re
import sys 
import time
import requests
import subprocess

def led_on():
    os.system("sudo gpioset 0 0=1")

def led_off():
    os.system("sudo gpioset 0 0=0")

def spell_phrase(phrase):
    char_num = 1

    if(phrase!=None):
        [char for char in phrase]:
            if char == 'a' or char == 'A':
                led_on()

            elif char == 'b' or char == 'B':
                led_off()

            else:
                led_off()

        char_num = next_char_num
    else:
        phrase = "noPhrase"

    return phrase

def main(arg):
    phraseOut = spell_phrase(arg)

if __name__ == "__main__":
    main(sys.argv[1])
